/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package calcular.volume;

import Models.Viga;
import javax.swing.JOptionPane;

/**
 *
 * @author ricar
 */
public class CalcularVolume {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Viga viga = new Viga();
        viga.CalcularVolume();
    }
    
}
